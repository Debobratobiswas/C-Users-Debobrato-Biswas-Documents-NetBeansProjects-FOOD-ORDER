
package FOOD_ORDERING;
import javax.swing.*;
import java.awt.event.*;


public class FOOD_ORDERING extends JFrame implements ActionListener{

    //private static final long serialVersionUID = 1L;
    
      //JFrame f = new JFrame("Food Order");  
      JLabel l;
      JCheckBox cb1,cb2,cb3,cb4,cb5,cb6,cb7,cb8,cb9,cb10,cb11,cb12,cb13,cb14,cb15;
      JButton b;
      
      FOOD_ORDERING()
      {
          l= new JLabel("Food Ordering Menu");
          l.setBounds(50,50,300,20);
          cb1=new JCheckBox("Fiery Grilled Chicken "
                  + "Tk.140 BDT");
          cb1.setBounds(100, 100, 150, 20);
          
          cb2=new JCheckBox("Hot & Crispy Chicken "
                  + "Tk.140 BDT");
          cb2.setBounds(100, 150, 150, 20);
          
          cb3=new JCheckBox("Spicy Thai Chicken Rice "
                  + "Tk.265 BDT");
          cb3.setBounds(100, 200, 150, 20);
          
          cb4=new JCheckBox("Chicken Rice Meal "
                  + "Tk.190 BDT");
          cb4.setBounds(100, 250, 150, 20);
          
          cb5=new JCheckBox("Fusion Burger "
                  + "Tk.280 BDT");
          cb5.setBounds(100, 300, 150, 20);
          
          cb6=new JCheckBox("Veggie Fusion (Double Patties) "
                  + "Tk.300 BDT");
          cb6.setBounds(100, 350, 150, 20);
         
           cb7=new JCheckBox("Veggie Burger "
                  + "Tk.260 BDT");
          cb7.setBounds(100, 400, 150, 20);
          
          cb8=new JCheckBox("Zinger Burger "
                  + "Tk.260 BDT");
          cb8.setBounds(100, 450, 150, 20);
          
            cb9=new JCheckBox("Gril’d "
                  + "Tk.260 BDT");
          cb9.setBounds(100, 450, 150, 20);
          
            cb10=new JCheckBox("Chicken Snacker "
                  + "Tk.190 BDT");
          cb10.setBounds(100, 500, 150, 20);
          
           cb11=new JCheckBox("Popcorn "
                  + "Tk.180 BDT");
          cb11.setBounds(100, 550, 150, 20);
          
           cb12=new JCheckBox("Butterscotch / Exotic "
                  + "Tk.80 BDT");
          cb12.setBounds(100, 600, 150, 20);
          
          cb13=new JCheckBox("Vanilla / Chocolate / Strawberry"
                  + "Tk.70 BDT");
          cb13.setBounds(100, 650, 150, 20);
          
           cb14=new JCheckBox("Coffee "
                  + "Tk.70 BDT");
          cb14.setBounds(100, 700, 150, 20);
          
           cb15=new JCheckBox("Tea "
                  + "Tk.50 BDT");
          cb15.setBounds(100, 750, 150, 20);
          
          b=new JButton ("Order");
          b.setBounds(100, 800, 150, 20);
          b.addActionListener(this);
          
          add(l);
          add(cb1);
          add(cb2);
          add(cb3);
          add(cb4);
          add(cb5);
          add(cb6);
          add(cb7);
          add(cb8);
          add(cb9);
          add(cb10);
         /* add(cb11);
          add(cb12);
          add(cb13);
          add(cb14);
          add(cb15);*/
          add(b);
          setSize(500, 500);
          setLayout(null);
          setVisible(true);
          setDefaultCloseOperation(EXIT_ON_CLOSE); 
          
          
      }
      
       public void actionPerformed(ActionEvent e){  
        float amount=0;  
        String msg="";  
        if(cb1.isSelected()){  
            amount+=140;  
            msg+="Fiery Grilled Chicken : 140 \n";  
        }  
        if(cb2.isSelected()){  
            amount+=140;  
            msg+="Hot & Crispy Chicken :140\n";  
        }  
        if(cb3.isSelected()){  
            amount+=265;  
            msg+="Spicy Thai Chicken Rice :265\n";  
        } 
         if(cb4.isSelected()){  
            amount+=190;  
            msg+="Chicken Rice Meal: 190\n";  
        }  
          if(cb5.isSelected()){  
            amount+=280;  
            msg+="Fusion Burger: 280\n";  
        }  
           if(cb6.isSelected()){  
            amount+=300;  
            msg+="Veggie Fusion : 300\n";  
        }  
            if(cb7.isSelected()){  
            amount+=260;  
            msg+="Veggie Burger: 260\n";  
        }  
             if(cb8.isSelected()){  
            amount+=260;  
            msg+="Zinger Burger: 260\n";  
        }  
              if(cb9.isSelected()){  
            amount+=260;  
            msg+="Gril’d: 260\n";  
        }  
               if(cb10.isSelected()){  
            amount+=190;  
            msg+="Chicken Snacker: 190\n";  
        }  
                if(cb11.isSelected()){  
            amount+=180;  
            msg+="Popcorn: 180\n";  
        }  
                 if(cb12.isSelected()){  
            amount+=80;  
            msg+="Butterscotch: 80\n";  
        }  
                  if(cb13.isSelected()){  
            amount+=70;  
            msg+="Strawberry: 70\n";  
        }  
                   if(cb14.isSelected()){  
            amount+=70;  
            msg+="Coffee: 70\n";  
        }   if(cb15.isSelected()){  
            amount+=50;  
            msg+="Tea : 50\n";  
        }  
        
                   
        msg+="-----------------\n";  
        JOptionPane.showMessageDialog(this,msg+"Total: "+amount);  
    }  
      

    
    public static void main(String[] args) {
       new FOOD_ORDERING();
    }    
}
